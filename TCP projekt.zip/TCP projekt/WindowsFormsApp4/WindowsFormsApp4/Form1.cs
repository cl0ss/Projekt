﻿using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Net.Http;

namespace WindowsFormsApp4
{

    public partial class Form1 : Form
    {
        private string selectedFilePath = string.Empty;
        private const int listenPort = 9009;
        private string user;
        string tooltipTekst;

        public Form1(string name)
        {
            InitializeComponent();
            user = name;
            StartListening();
            this.Text = $"Korisnik: {user}";

        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            tooltipTekst += "Tvoj port za primanje je: " + listenPort.ToString() + '\n';
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork && !ip.ToString().StartsWith("192.168.56"))
                {
                    tooltipTekst += "Tvoja lokalna IP adresa je: " + ip.ToString() + '\n';

                }
            }
            string publicIP = "Nepoznata";
            using (var client = new System.Net.Http.HttpClient())
            {
                publicIP = (await client.GetStringAsync("https://api.ipify.org")).Trim();
            }
            tooltipTekst += "Tvoja javna IP adresa je: " + publicIP + '\n';
            toolTip1.SetToolTip(label6, tooltipTekst);
        }


        private async void button1_Click_1(object sender, EventArgs e)
        {
            string ip = textBox1.Text;
            int port;
            if (!int.TryParse(textBox2.Text, out port))
            {
                MessageBox.Show("Unesite ispravan broj porta.");
                return;
            }

            if (string.IsNullOrEmpty(selectedFilePath))
            {
                MessageBox.Show("Datoteka nije odabrana.");
                return;
            }

            FileInfo fileInfo = new FileInfo(selectedFilePath);

            try
            {
                using (TcpClient client = new TcpClient())
                {
                    await client.ConnectAsync(IPAddress.Parse(ip), port);
                    using (NetworkStream stream = client.GetStream())
                    {
                        FileOffer offer = new FileOffer { imeDat = fileInfo.Name, velicinaDat = fileInfo.Length, posiljatelj = user };
                        string json = JsonSerializer.Serialize(offer);
                        byte[] headerBytes = Encoding.UTF8.GetBytes(json);
                        await stream.WriteAsync(headerBytes, 0, headerBytes.Length);
                        byte[] response = new byte[10];
                        int bytesRead = await stream.ReadAsync(response, 0, response.Length);
                        string respStr = Encoding.UTF8.GetString(response, 0, bytesRead).Trim('\0');

                        if (respStr == "Prihvati")
                        {
                            using (FileStream fs = new FileStream(selectedFilePath, FileMode.Open, FileAccess.Read))
                            {
                                await fs.CopyToAsync(stream);
                            }
                            MessageBox.Show("Datoteka poslana.");
                        }
                        else
                        {
                            MessageBox.Show("Zahtjev za slanje odbijen.");
                        }
                    }
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("IP adresa nije ispravnog formata.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Došlo je do pogreške: " + ex.Message);
            }
        }

        private async void StartListening()
        {
            TcpListener listener = new TcpListener(IPAddress.Any, listenPort);
            listener.Start();
            await Task.Run(async () =>
            {
                while (true)
                {
                    TcpClient client = await listener.AcceptTcpClientAsync();
                    _ = Task.Run(() => HandleIncomingConnection(client));
                }
            });
        }

        private async Task HandleIncomingConnection(TcpClient client)
        {
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[1024];
            int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
            string json = Encoding.UTF8.GetString(buffer, 0, bytesRead);

            try
            {
                FileOffer offer = JsonSerializer.Deserialize<FileOffer>(json);

                DialogResult result = MessageBox.Show($"Korisnik '{offer.posiljatelj}' želi poslati datoteku '{offer.imeDat}' ({offer.velicinaDat} bajtova).\nPrihvatiti?", "Prijem datoteke", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    byte[] response = Encoding.UTF8.GetBytes("Prihvati");
                    await stream.WriteAsync(response, 0, response.Length);

                    string selectedPath = null;
                    Invoke((MethodInvoker)(() =>
                    {
                        SaveFileDialog sfd = new SaveFileDialog { FileName = offer.imeDat };
                        if (sfd.ShowDialog() == DialogResult.OK)
                        {
                            selectedPath = sfd.FileName;
                        }
                    }));

                    if (!string.IsNullOrEmpty(selectedPath))
                    {
                        using (FileStream fs = new FileStream(selectedPath, FileMode.Create, FileAccess.Write))
                        {
                            await stream.CopyToAsync(fs);
                        }
                        MessageBox.Show("Datoteka primljena.");

                        if (Path.GetExtension(selectedPath).ToLower() == ".txt")
                        {
                            string textContent = File.ReadAllText(selectedPath);
                            Invoke((MethodInvoker)(() =>
                            {
                                textBox4.Visible = true;
                                pictureBox1.Visible = false;
                                textBox4.Text = textContent;
                            }));
                        }
                        else if (Path.GetExtension(selectedPath).ToLower() == ".jpg" || Path.GetExtension(selectedPath).ToLower() == ".jpeg" || Path.GetExtension(selectedPath).ToLower() == ".png" || Path.GetExtension(selectedPath).ToLower() == ".bmp" || Path.GetExtension(selectedPath).ToLower() == ".gif")
                        {
                            Invoke((MethodInvoker)(() =>
                            {
                                textBox4.Visible = false;
                                pictureBox1.Visible = true;
                                pictureBox1.Image = Image.FromFile(selectedPath);
                            }));
                        }
                    }
                }
                else
                {
                    byte[] response = Encoding.UTF8.GetBytes("Odbijam");
                    await stream.WriteAsync(response, 0, response.Length);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Deserijalizacija nije uspjela: " + ex.Message);
            }

            stream.Close();
            client.Close();
        }

        private void odaberiDat_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                selectedFilePath = ofd.FileName;
                textBox3.Text = Path.GetFileName(selectedFilePath);
            }
        }
    }
    public class FileOffer
    {
        public string imeDat { get; set; }
        public long velicinaDat { get; set; }
        public string posiljatelj { get; set; }
    }
}
